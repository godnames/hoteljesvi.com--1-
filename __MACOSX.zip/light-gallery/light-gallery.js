// JavaScript Document

 
        $(document).ready(function(){
            $('#lightgallery').lightGallery();
        });
        